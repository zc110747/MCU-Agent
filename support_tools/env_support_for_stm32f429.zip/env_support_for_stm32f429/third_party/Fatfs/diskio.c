/*-----------------------------------------------------------------------*/
/* Low level disk I/O glue: STM32F429 SDIO (SD card) -> FatFs            */
/*-----------------------------------------------------------------------*/

#include "ff.h"			/* Obtains integer types */
#include "diskio.h"		/* Declarations of disk functions */
#include "bsp_sdio.h"

/* Physical drive number for the SD card. */
#define DEV_SD		0

/*-----------------------------------------------------------------------*/
/* Get Drive Status                                                      */
/*-----------------------------------------------------------------------*/
DSTATUS disk_status (
	BYTE pdrv		/* Physical drive nmuber to identify the drive */
)
{
	if (pdrv != DEV_SD) return STA_NOINIT;
	if (HAL_SD_GetCardState(&hsdcard1) == HAL_SD_CARD_TRANSFER)
		return 0;			/* ready */
	return STA_NOINIT;
}

/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */
/*-----------------------------------------------------------------------*/
DSTATUS disk_initialize (
	BYTE pdrv		/* Physical drive nmuber to identify the drive */
)
{
	if (pdrv != DEV_SD) return STA_NOINIT;
	return 0;   /* bsp_sdio_init() already ran; treat as ready */
}

/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/
DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber to identify the drive */
	BYTE *buff,		/* Data buffer to store read data */
	LBA_t sector,	/* Start sector in LBA */
	UINT count		/* Number of sectors to read */
)
{
	if (pdrv != DEV_SD) return RES_PARERR;
	if (sdcard_read_disk(buff, (uint32_t)sector, (uint32_t)count) != HAL_OK)
		return RES_ERROR;
	return RES_OK;
}

/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/
#if FF_FS_READONLY == 0
DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber to identify the drive */
	const BYTE *buff,	/* Data to be written */
	LBA_t sector,		/* Start sector in LBA */
	UINT count			/* Number of sectors to write */
)
{
	if (pdrv != DEV_SD) return RES_PARERR;
	if (sdcard_write_disk(buff, (uint32_t)sector, (uint32_t)count) != HAL_OK)
		return RES_ERROR;
	return RES_OK;
}
#endif

/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/
DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	DRESULT res = RES_ERROR;

	if (pdrv != DEV_SD) return RES_PARERR;

	switch (cmd)
	{
	case CTRL_SYNC:
		res = RES_OK;
		break;

	case GET_SECTOR_COUNT:
		*(LBA_t *)buff = (LBA_t)hsdcard1.SdCard.BlockNbr;
		res = RES_OK;
		break;

	case GET_SECTOR_SIZE:
		*(WORD *)buff = (WORD)hsdcard1.SdCard.BlockSize;
		res = RES_OK;
		break;

	case GET_BLOCK_SIZE:
		*(DWORD *)buff = 1;		/* erase block size in sectors */
		res = RES_OK;
		break;

	default:
		res = RES_PARERR;
	}

	return res;
}

/*-----------------------------------------------------------------------*/
/* System Timer                                                          */
/*-----------------------------------------------------------------------*/
#if FF_FS_NORTC == 0
DWORD get_fattime (void)
{
	/* no RTC on the board: return a fixed timestamp (2026-01-01 00:00:00) */
	return ((DWORD)(2026 - 1980) << 25) | ((DWORD)1 << 21) | ((DWORD)1 << 16);
}
#endif
